<?php
session_start();

require_once __DIR__ . "/Config/db.php";

$page = $_GET["page"] ?? "home";

$allowed_pages = [
  "home",
  "leaderboard",
  "pae",
  "search",
  "charts",
  "all_players",
  "predictor",
  "projections",
  "compare",
  "model_eval",
  "player",
  "rating_bands",
  "login",
  "logout",
  "security_logs",
  "admin_users"
];

if (!in_array($page, $allowed_pages, true)) {
  $page = "home";
}

// Public pages
$public_pages = ["home", "login"];

// Require login for everything except home and login
if (!in_array($page, $public_pages, true) && !isset($_SESSION["user_id"])) {
  header("Location: index.php?page=login");
  exit;
}

require_once __DIR__ . "/Includes/header.php";
require_once __DIR__ . "/Pages/{$page}.php";
require_once __DIR__ . "/Includes/footer.php";