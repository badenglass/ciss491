from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List
import json
import os
from datetime import datetime

from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

app = FastAPI()

API_KEY = "capstone-secure-key-2025"

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter


@app.exception_handler(RateLimitExceeded)
def rate_limit_handler(request: Request, exc: RateLimitExceeded):
    write_security_log(request, request.url.path, "RATE_LIMIT_EXCEEDED")
    return JSONResponse(
        status_code=429,
        content={"detail": "Rate limit exceeded. Please try again later."}
    )


with open("regression_model.json", "r") as file:
    model_data = json.load(file)

INTERCEPT = model_data["intercept"]
B_RATING = model_data["coefficients"]["Rating"]
B_EVENTS = model_data["coefficients"]["Events_Played"]
B_INTERACTION = model_data["coefficients"]["Rating_x_Events"]


class PlayerInput(BaseModel):
    rating: float
    events_played: float


class BatchInput(BaseModel):
    players: List[PlayerInput]


def write_security_log(request: Request, endpoint: str, status: str) -> None:
    log_dir = "logs"
    log_file = os.path.join(log_dir, "api_security.log")

    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    client_ip = request.client.host if request.client else "unknown"

    log_entry = f"[{timestamp}] [IP: {client_ip}] [{endpoint}] {status}\n"

    with open(log_file, "a", encoding="utf-8") as f:
        f.write(log_entry)


def verify_api_key(request: Request, x_api_key: str = Header(None)) -> None:
    if x_api_key != API_KEY:
        write_security_log(request, request.url.path, "UNAUTHORIZED")
        raise HTTPException(status_code=401, detail="Unauthorized")


def calculate_prediction(rating: float, events_played: float) -> float:
    interaction = rating * events_played

    predicted_points = (
        INTERCEPT
        + B_RATING * rating
        + B_EVENTS * events_played
        + B_INTERACTION * interaction
    )

    return round(predicted_points, 2)


@app.get("/")
def root():
    return {"message": "PDGA prediction API is running."}


@app.post("/predict")
@limiter.limit("20/minute")
def predict(request: Request, data: PlayerInput, x_api_key: str = Header(None)):
    verify_api_key(request, x_api_key)

    predicted_points = calculate_prediction(data.rating, data.events_played)
    write_security_log(request, "/predict", "SUCCESS")

    return {
        "rating": data.rating,
        "events_played": data.events_played,
        "predicted_points": predicted_points
    }


@app.post("/predict_batch")
@limiter.limit("10/minute")
def predict_batch(request: Request, data: BatchInput, x_api_key: str = Header(None)):
    verify_api_key(request, x_api_key)

    results = []

    for player in data.players:
        predicted_points = calculate_prediction(player.rating, player.events_played)
        results.append({
            "rating": player.rating,
            "events_played": player.events_played,
            "predicted_points": predicted_points
        })

    write_security_log(request, "/predict_batch", "SUCCESS")
    return {"results": results}