<?php
function write_security_log(string $message): void
{
    $logDir = __DIR__ . '/../logs';
    $logFile = $logDir . '/security.log';

    if (!is_dir($logDir)) {
        mkdir($logDir, 0777, true);
    }

    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $time = date('Y-m-d H:i:s');
    $requestUri = $_SERVER['REQUEST_URI'] ?? 'unknown';

    $entry = "[{$time}] [IP: {$ip}] [URI: {$requestUri}] {$message}" . PHP_EOL;

    file_put_contents($logFile, $entry, FILE_APPEND);
}