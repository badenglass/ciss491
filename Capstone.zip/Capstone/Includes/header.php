<?php
// Security headers
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("Referrer-Policy: strict-origin-when-cross-origin");
header("Permissions-Policy: geolocation=(), microphone=(), camera=()");
header("Content-Security-Policy: default-src 'self' https: 'unsafe-inline' 'unsafe-eval'; img-src 'self' data: https:; script-src 'self' https: 'unsafe-inline' 'unsafe-eval'; style-src 'self' https: 'unsafe-inline';");
?>
<!doctype html>
<html lang="en">
<head>
  <style>

.player-link {
  text-decoration: none;
  font-weight: 600;
  color: #212529;
  transition: color 0.2s ease;
}

.player-link:hover {
  color: #0d6efd;
  text-decoration: underline;
}

</style>
  <meta charset="utf-8">
  <title>PDGA Capstone</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Chart.js (for charts page) -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light d-flex flex-column min-vh-100">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid px-4">
    <a class="navbar-brand fw-bold" href="index.php?page=home">PDGA MPO 2025</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav ms-auto">
      <li class="nav-item"><a class="nav-link" href="index.php?page=home">Home</a></li>

      <?php if (isset($_SESSION["user_id"])): ?>
        <li class="nav-item"><a class="nav-link" href="index.php?page=leaderboard">Leaderboard</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php?page=pae">PAE</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php?page=charts">Charts</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php?page=search">Search</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php?page=all_players">All Players</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php?page=predictor">Predictor</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php?page=projections">Projections</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php?page=compare">Compare</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php?page=model_eval">Model Eval</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php?page=rating_bands">Rating Bands</a></li>

        <li class="nav-item">
          <span class="nav-link">Hello, <?= htmlspecialchars($_SESSION["username"]) ?></span>
        </li>

        <?php if (isset($_SESSION["role"]) && $_SESSION["role"] === "admin"): ?>
          <li class="nav-item">
            <a class="nav-link text-warning" href="index.php?page=security_logs">Security Dashboard</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-info" href="index.php?page=admin_users">User Management</a>
          </li>
        <?php endif; ?>

        <li class="nav-item">
          <a class="nav-link text-danger" href="index.php?page=logout">Logout</a>
        </li>
      <?php else: ?>
        <li class="nav-item">
          <a class="nav-link" href="index.php?page=login">Login</a>
        </li>
      <?php endif; ?>
    </ul>
    </div>
  </div>
</nav>

<div class="container py-4 flex-grow-1">
