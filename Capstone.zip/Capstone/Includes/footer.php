<?php
// includes/footer.php
?>
</div>

<footer class="bg-light border-top mt-auto">
  <div class="container py-3 text-center text-muted">
    PDGA Capstone Dashboard © 2026
  </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
