<?php
require_once __DIR__ . '/../includes/security_log.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    write_security_log("Invalid request method used on Api/predict.php.");

    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.'
    ]);
    exit;
}

$rawInput = file_get_contents("php://input");

if ($rawInput === false || trim($rawInput) === '') {

    write_security_log("No input data received in Api/predict.php.");

    echo json_encode([
        'success' => false,
        'message' => 'No input data received.'
    ]);
    exit;
}

$data = json_decode($rawInput, true);

if (!is_array($data)) {

    write_security_log("Invalid JSON input received in Api/predict.php.");

    echo json_encode([
        'success' => false,
        'message' => 'Invalid JSON input.'
    ]);
    exit;
}

if (!isset($data['rating'], $data['events_played'])) {

    write_security_log("Missing required predictor values.");

    echo json_encode([
        'success' => false,
        'message' => 'Missing required input values.'
    ]);
    exit;
}

$rating = filter_var($data['rating'], FILTER_VALIDATE_FLOAT);
$events_played = filter_var($data['events_played'], FILTER_VALIDATE_FLOAT);

if ($rating === false || $events_played === false) {

    write_security_log("Non-numeric predictor input received.");

    echo json_encode([
        'success' => false,
        'message' => 'Input values must be numeric.'
    ]);
    exit;
}

if ($rating <= 0 || $events_played < 0) {

    write_security_log("Out-of-range predictor values submitted.");

    echo json_encode([
        'success' => false,
        'message' => 'Please enter valid values.'
    ]);
    exit;
}

$payload = json_encode([
    'rating' => $rating,
    'events_played' => $events_played
]);

$ch = curl_init('http://localhost:8000/predict');

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'X-API-Key: capstone-secure-key-2025'
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {

    write_security_log("Prediction API cURL request failed.");

    curl_close($ch);

    echo json_encode([
        'success' => false,
        'message' => 'Prediction service unavailable.'
    ]);
    exit;
}

curl_close($ch);

if ($httpCode !== 200 || !$response) {

    write_security_log("Prediction API returned non-200 response.");

    echo json_encode([
        'success' => false,
        'message' => 'Could not connect to prediction API.'
    ]);
    exit;
}

$apiResult = json_decode($response, true);

if (!is_array($apiResult) || !isset($apiResult['predicted_points'])) {

    write_security_log("Prediction API returned invalid JSON.");

    echo json_encode([
        'success' => false,
        'message' => 'Invalid response from prediction API.'
    ]);
    exit;
}

echo json_encode([
    'success' => true,
    'rating' => $apiResult['rating'],
    'events_played' => $apiResult['events_played'],
    'predicted_points' => $apiResult['predicted_points']
]);