<?php
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../includes/security_log.php';

header('Content-Type: application/json');

$allowedMetrics = ['Rating', 'Points', 'PAE'];
$allowedLimits = [5, 10, 25, 50];

$metric = $_GET['metric'] ?? 'Points';
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;

if (!in_array($metric, $allowedMetrics, true)) {
    write_security_log("Invalid leaderboard metric requested: " . $metric);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid metric.'
    ]);
    exit;
}

if (!in_array($limit, $allowedLimits, true)) {
    write_security_log("Invalid leaderboard limit requested: " . $limit);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid limit.'
    ]);
    exit;
}

try {
    if ($metric === 'PAE') {
        $stmt = $pdo->prepare("
            SELECT
                p.PDGA_Number,
                p.Player_Name,
                CAST(p.Rating AS DECIMAL(10,2)) AS Rating,
                CAST(p.Events_Played AS DECIMAL(10,2)) AS Events_Played,
                CAST(p.Points AS DECIMAL(10,2)) AS Points,
                CAST(p.PAE AS DECIMAL(10,2)) AS MetricValue
            FROM pae_model p
            ORDER BY CAST(p.PAE AS DECIMAL(10,2)) DESC, p.Player_Name ASC
            LIMIT ?
        ");
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->execute();
    } elseif ($metric === 'Points') {
        $stmt = $pdo->prepare("
            SELECT
                r.PDGA_Number,
                r.Player_Name,
                CAST(r.Rating AS DECIMAL(10,2)) AS Rating,
                CAST(r.Events_Played AS DECIMAL(10,2)) AS Events_Played,
                CAST(REPLACE(r.Points, ',', '') AS DECIMAL(10,2)) AS Points,
                CAST(REPLACE(r.Points, ',', '') AS DECIMAL(10,2)) AS MetricValue
            FROM raw_data r
            WHERE r.Year = 2025
            ORDER BY MetricValue DESC, r.Player_Name ASC
            LIMIT ?
        ");
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->execute();
    } else {
        $stmt = $pdo->prepare("
            SELECT
                r.PDGA_Number,
                r.Player_Name,
                CAST(r.Rating AS DECIMAL(10,2)) AS Rating,
                CAST(r.Events_Played AS DECIMAL(10,2)) AS Events_Played,
                CAST(REPLACE(r.Points, ',', '') AS DECIMAL(10,2)) AS Points,
                CAST(r.Rating AS DECIMAL(10,2)) AS MetricValue
            FROM raw_data r
            WHERE r.Year = 2025
            ORDER BY CAST(r.Rating AS DECIMAL(10,2)) DESC,
                     CAST(REPLACE(r.Points, ',', '') AS DECIMAL(10,2)) DESC,
                     r.Player_Name ASC
            LIMIT ?
        ");
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->execute();
    }

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'metric' => $metric,
        'limit' => $limit,
        'rows' => $rows
    ]);
} catch (Throwable $e) {
    write_security_log("Leaderboard API failure.");
    echo json_encode([
        'success' => false,
        'message' => 'Unable to load leaderboard data.'
    ]);
}