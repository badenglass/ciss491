<?php
require_once __DIR__ . "/../config/db.php";

$sql = "
  SELECT Player_Name, PAE
  FROM pae_model
  ORDER BY PAE DESC
  LIMIT 10
";
$stmt = $pdo->query($sql);
$rows = $stmt->fetchAll();

header("Content-Type: application/json");
echo json_encode($rows);
