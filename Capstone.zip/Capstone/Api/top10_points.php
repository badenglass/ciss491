<?php
// api/top10_points.php
require_once __DIR__ . "/../config/db.php";

$sql = "
  SELECT Player_Name, Points
  FROM raw_data
  ORDER BY Points DESC
  LIMIT 10
";
$stmt = $pdo->query($sql);
$rows = $stmt->fetchAll();

header("Content-Type: application/json");
echo json_encode($rows);
