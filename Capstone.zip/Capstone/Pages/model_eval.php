<?php
$stmt = $pdo->query("
    SELECT
        r.Player_Name,
        r.Rating,
        r.Events_Played,
        CAST(REPLACE(r.Points, ',', '') AS UNSIGNED) AS Actual_Points
    FROM raw_data r
    WHERE r.Year = 2025
    ORDER BY Actual_Points DESC
    LIMIT 200
");

$players = $stmt->fetchAll(PDO::FETCH_ASSOC);

$apiPlayers = [];

foreach ($players as $player) {
    $apiPlayers[] = [
        "rating" => (float)$player["Rating"],
        "events_played" => (float)$player["Events_Played"]
    ];
}

$payload = json_encode([
    "players" => $apiPlayers
]);

$ch = curl_init("http://localhost:8000/predict_batch");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "X-API-Key: capstone-secure-key-2025"
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$predictions = [];

if ($httpCode === 200 && $response) {
    $apiResult = json_decode($response, true);
    if (isset($apiResult["results"])) {
        $predictions = $apiResult["results"];
    }
}

$rows = [];
$actual = [];
$predicted = [];

foreach ($players as $i => $player) {
    $pred = $predictions[$i]["predicted_points"] ?? null;
    $act = (float)$player["Actual_Points"];

    if ($pred !== null) {
        $actual[] = $act;
        $predicted[] = (float)$pred;
    }

    $rows[] = [
        "Player_Name" => $player["Player_Name"],
        "Actual_Points" => $act,
        "Predicted_Points" => $pred,
        "Error" => $pred !== null ? ((float)$pred - $act) : null
    ];
}

$mae = 0;
$rmse = 0;
$r2 = 0;

if (count($actual) > 0) {
    $n = count($actual);
    $meanActual = array_sum($actual) / $n;

    $absError = 0;
    $sqError = 0;
    $ssTotal = 0;
    $ssResidual = 0;

    foreach ($actual as $i => $a) {
        $p = $predicted[$i];
        $absError += abs($a - $p);
        $sqError += pow($a - $p, 2);
        $ssTotal += pow($a - $meanActual, 2);
        $ssResidual += pow($a - $p, 2);
    }

    $mae = $absError / $n;
    $rmse = sqrt($sqError / $n);
    $r2 = $ssTotal > 0 ? 1 - ($ssResidual / $ssTotal) : 0;
}

usort($rows, function ($a, $b) {
    return abs($b["Error"] ?? 0) <=> abs($a["Error"] ?? 0);
});

$topErrors = array_slice($rows, 0, 10);
$errorLabels = [];
$errorValues = [];

foreach ($topErrors as $row) {
    $errorLabels[] = $row["Player_Name"];
    $errorValues[] = round((float)$row["Error"], 2);
}
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h2 class="mb-0">Model Evaluation</h2>
    <small class="text-muted">Regression performance on 2025 MPO players</small>
  </div>
</div>

<div class="alert alert-secondary">
  <strong>Evaluation Overview:</strong>
  This page measures how well the regression model predicts season points using player rating and events played.
</div>

<div class="row g-3 mb-4">
  <div class="col-md-4">
    <div class="card shadow-sm border-primary h-100">
      <div class="card-body">
        <div class="text-muted small">R² Score</div>
        <div class="fs-2 fw-bold text-primary"><?= number_format($r2, 3) ?></div>
        <div class="small text-muted">Variance explained by model</div>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card shadow-sm border-warning h-100">
      <div class="card-body">
        <div class="text-muted small">MAE</div>
        <div class="fs-2 fw-bold text-warning"><?= number_format($mae, 2) ?></div>
        <div class="small text-muted">Average absolute prediction error</div>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card shadow-sm border-danger h-100">
      <div class="card-body">
        <div class="text-muted small">RMSE</div>
        <div class="fs-2 fw-bold text-danger"><?= number_format($rmse, 2) ?></div>
        <div class="small text-muted">Root mean squared error</div>
      </div>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-8">
    <div class="card shadow-sm">
      <div class="card-body">
        <h4 class="card-title mb-3">Largest Prediction Errors</h4>
        <canvas id="errorChart" height="130"></canvas>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card shadow-sm border-info h-100">
      <div class="card-body">
        <h5 class="text-info">What this shows</h5>
        <p class="mb-2">This chart highlights the players with the largest gaps between predicted and actual points.</p>
        <p class="mb-0">Positive values mean the model overpredicted. Negative values mean the model underpredicted.</p>
      </div>
    </div>
  </div>
</div>

<script>
const errorLabels = <?= json_encode($errorLabels) ?>;
const errorValues = <?= json_encode($errorValues) ?>;

new Chart(document.getElementById('errorChart'), {
  type: 'bar',
  data: {
    labels: errorLabels,
    datasets: [{
      label: 'Prediction Error',
      data: errorValues,
      backgroundColor: errorValues.map(v =>
        v >= 0 ? 'rgba(25,135,84,0.75)' : 'rgba(220,53,69,0.75)'
      ),
      borderRadius: 6
    }]
  },
  options: {
    responsive: true,
    plugins: {
      legend: { display: false }
    },
    scales: {
      x: {
        ticks: {
          maxRotation: 45,
          minRotation: 45
        }
      },
      y: {
        beginAtZero: true
      }
    }
  }
});
</script>