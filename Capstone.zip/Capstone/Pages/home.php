<?php
// NOTE: This page assumes $pdo already exists (from index.php / Config/db.php).

// ----------------------------
// Summary cards
// ----------------------------
$stmt = $pdo->query("SELECT COUNT(*) AS total_players FROM raw_data");
$totalPlayers = (int)($stmt->fetch(PDO::FETCH_ASSOC)['total_players'] ?? 0);

$stmt = $pdo->query("SELECT MAX(Rating) AS top_rating FROM raw_data");
$topRating = (int)($stmt->fetch(PDO::FETCH_ASSOC)['top_rating'] ?? 0);

$stmt = $pdo->query("
  SELECT MAX(CAST(REPLACE(Points, ',', '') AS UNSIGNED)) AS top_points
  FROM raw_data
");
$topPoints = (int)($stmt->fetch(PDO::FETCH_ASSOC)['top_points'] ?? 0);

$stmt = $pdo->query("SELECT AVG(Rating) AS avg_rating FROM raw_data");
$avgRating = (float)($stmt->fetch(PDO::FETCH_ASSOC)['avg_rating'] ?? 0);

// ----------------------------
// Featured leaders
// ----------------------------
$topRatedStmt = $pdo->query("
  SELECT Player_Name, Rating, CAST(REPLACE(Points, ',', '') AS UNSIGNED) AS PointsNum
  FROM raw_data
  ORDER BY Rating DESC, PointsNum DESC, Player_Name ASC
  LIMIT 1
");
$topRatedPlayer = $topRatedStmt->fetch(PDO::FETCH_ASSOC);

$topPointsStmt = $pdo->query("
  SELECT Player_Name, Rating, CAST(REPLACE(Points, ',', '') AS UNSIGNED) AS PointsNum
  FROM raw_data
  ORDER BY PointsNum DESC, Rating DESC, Player_Name ASC
  LIMIT 1
");
$topPointsPlayer = $topPointsStmt->fetch(PDO::FETCH_ASSOC);

$topPAEStmt = $pdo->query("
  SELECT Player_Name, PAE, Points
  FROM pae_model
  ORDER BY PAE DESC, Points DESC, Player_Name ASC
  LIMIT 1
");
$topPAEPlayer = $topPAEStmt->fetch(PDO::FETCH_ASSOC);

// ----------------------------
// Top 5 by Rating table
// ----------------------------
$top5Stmt = $pdo->query("
  SELECT
    PDGA_Number,
    Player_Name,
    Rating,
    CAST(REPLACE(Points, ',', '') AS UNSIGNED) AS PointsNum
  FROM raw_data
  ORDER BY Rating DESC, PointsNum DESC, Player_Name ASC
  LIMIT 5
");
$top5 = $top5Stmt->fetchAll(PDO::FETCH_ASSOC);

// ----------------------------
// Top 5 by Points chart
// ----------------------------
$chartStmt = $pdo->query("
  SELECT
    Player_Name,
    CAST(REPLACE(Points, ',', '') AS UNSIGNED) AS PointsNum
  FROM raw_data
  ORDER BY PointsNum DESC, Rating DESC, Player_Name ASC
  LIMIT 5
");
$chartRows = $chartStmt->fetchAll(PDO::FETCH_ASSOC);

$chartLabels = [];
$chartValues = [];

foreach ($chartRows as $row) {
    $chartLabels[] = $row['Player_Name'];
    $chartValues[] = (int)$row['PointsNum'];
}
?>

<div class="card shadow-sm border-0 mb-4" style="background: linear-gradient(135deg, #1f2937 0%, #111827 100%); color: white;">
  <div class="card-body p-4 p-lg-5">
    <div class="row align-items-center g-4">
      <div class="col-lg-8">
        <div class="text-uppercase small mb-2" style="letter-spacing: 1px; opacity: 0.8;">PDGA MPO 2025 Analytics Dashboard</div>
        <h1 class="display-5 fw-bold mb-3">Track performance, projections, and player insights</h1>
        <p class="mb-4" style="max-width: 700px; opacity: 0.9;">
          Explore 2025 MPO data through player rankings, PAE modeling, side-by-side comparisons,
          and machine learning predictions based on rating and events played.
        </p>

        <div class="d-flex flex-wrap gap-2">
          <a class="btn btn-light fw-semibold" href="index.php?page=projections">Explore Projections</a>
          <a class="btn btn-outline-light fw-semibold" href="index.php?page=compare">Compare Players</a>
          <a class="btn btn-outline-light fw-semibold" href="index.php?page=predictor">Open Predictor</a>
        </div>
      </div>

      <div class="col-lg-4">
        <div class="card border-0 shadow-sm" style="background: rgba(255,255,255,0.08); color: white;">
          <div class="card-body">
            <div class="small text-uppercase mb-2" style="opacity: 0.8;">Current Snapshot</div>
            <h5 class="fw-bold mb-3"><?= htmlspecialchars($topRatedPlayer['Player_Name'] ?? 'N/A') ?></h5>
            <div class="mb-2"><strong>Top Rating:</strong> <?= number_format((int)($topRatedPlayer['Rating'] ?? 0)) ?></div>
            <div class="mb-2"><strong>Top Points:</strong> <?= number_format((int)($topPointsPlayer['PointsNum'] ?? 0)) ?></div>
            <div class="mb-0"><strong>Top PAE:</strong> <?= number_format((float)($topPAEPlayer['PAE'] ?? 0), 2) ?></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row g-3 mb-4">
  <div class="col-12 col-md-6 col-xl-3">
    <div class="card shadow-sm border-primary h-100">
      <div class="card-body">
        <div class="text-muted small">Players in Dataset</div>
        <div class="fs-2 fw-bold"><?= number_format($totalPlayers); ?></div>
        <div class="small text-muted">Active 2025 records</div>
      </div>
    </div>
  </div>

  <div class="col-12 col-md-6 col-xl-3">
    <div class="card shadow-sm border-success h-100">
      <div class="card-body">
        <div class="text-muted small">Highest Rating</div>
        <div class="fs-2 fw-bold"><?= number_format($topRating); ?></div>
        <div class="small text-muted"><?= htmlspecialchars($topRatedPlayer['Player_Name'] ?? 'Season leader'); ?></div>
      </div>
    </div>
  </div>

  <div class="col-12 col-md-6 col-xl-3">
    <div class="card shadow-sm border-warning h-100">
      <div class="card-body">
        <div class="text-muted small">Highest Points</div>
        <div class="fs-2 fw-bold"><?= number_format($topPoints); ?></div>
        <div class="small text-muted"><?= htmlspecialchars($topPointsPlayer['Player_Name'] ?? 'Points leader'); ?></div>
      </div>
    </div>
  </div>

  <div class="col-12 col-md-6 col-xl-3">
    <div class="card shadow-sm border-info h-100">
      <div class="card-body">
        <div class="text-muted small">Average Rating</div>
        <div class="fs-2 fw-bold"><?= number_format($avgRating, 1); ?></div>
        <div class="small text-muted">Across all 2025 MPO players</div>
      </div>
    </div>
  </div>
</div>

<div class="row g-3 mb-4">
  <div class="col-md-4">
    <div class="card shadow-sm border-success h-100">
      <div class="card-body">
        <div class="text-muted small">Highest Rated Player</div>
        <h4 class="fw-bold mb-1"><?= htmlspecialchars($topRatedPlayer['Player_Name'] ?? 'N/A'); ?></h4>
        <div class="fs-4 text-success fw-bold"><?= number_format((int)($topRatedPlayer['Rating'] ?? 0)); ?></div>
        <div class="small text-muted">Current rating leader</div>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card shadow-sm border-warning h-100">
      <div class="card-body">
        <div class="text-muted small">Points Leader</div>
        <h4 class="fw-bold mb-1"><?= htmlspecialchars($topPointsPlayer['Player_Name'] ?? 'N/A'); ?></h4>
        <div class="fs-4 text-warning fw-bold"><?= number_format((int)($topPointsPlayer['PointsNum'] ?? 0)); ?></div>
        <div class="small text-muted">Top season points total</div>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card shadow-sm border-primary h-100">
      <div class="card-body">
        <div class="text-muted small">Top PAE</div>
        <h4 class="fw-bold mb-1"><?= htmlspecialchars($topPAEPlayer['Player_Name'] ?? 'N/A'); ?></h4>
        <div class="fs-4 text-primary fw-bold"><?= number_format((float)($topPAEPlayer['PAE'] ?? 0), 2); ?></div>
        <div class="small text-muted">Best points above expectation</div>
      </div>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-12 col-xl-8">
    <div class="card shadow-sm h-100">
      <div class="card-header bg-white fw-semibold">Top 5 by Points</div>
      <div class="card-body">
        <canvas id="homePointsChart" height="120"></canvas>
      </div>
    </div>
  </div>

  <div class="col-12 col-xl-4">
    <div class="card shadow-sm h-100">
      <div class="card-header bg-white fw-semibold">Quick Actions</div>
      <div class="card-body d-grid gap-3">
        <a class="btn btn-outline-dark text-start" href="index.php?page=projections">
          <div class="fw-semibold">Projections</div>
          <small class="text-muted">View model-based leaderboard insights</small>
        </a>

        <a class="btn btn-outline-dark text-start" href="index.php?page=predictor">
          <div class="fw-semibold">Predictor</div>
          <small class="text-muted">Estimate season points from rating and events</small>
        </a>

        <a class="btn btn-outline-dark text-start" href="index.php?page=compare">
          <div class="fw-semibold">Compare</div>
          <small class="text-muted">Analyze two players side by side</small>
        </a>

        <a class="btn btn-outline-dark text-start" href="index.php?page=charts">
          <div class="fw-semibold">Charts</div>
          <small class="text-muted">Explore leaderboard visual summaries</small>
        </a>
      </div>
    </div>
  </div>

  <div class="col-12 col-xl-8">
    <div class="card shadow-sm">
      <div class="card-header bg-white fw-semibold">Top 5 by Rating</div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-striped table-hover align-middle mb-0">
            <thead>
              <tr>
                <th>PDGA #</th>
                <th>Player</th>
                <th>Rating</th>
                <th>Points</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($top5 as $r): ?>
                <tr>
                  <td><?= htmlspecialchars($r['PDGA_Number'] ?? ''); ?></td>
                  <td class="fw-semibold">
                  <a class="player-link" href="index.php?page=player&pdga=<?= urlencode($r['PDGA_Number']) ?>">
                    <?= htmlspecialchars($r['Player_Name']) ?>
                  </a>
                  </td>
                  <td><?= htmlspecialchars($r['Rating'] ?? ''); ?></td>
                  <td><?= number_format((int)($r['PointsNum'] ?? 0)); ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-xl-4">
    <div class="card shadow-sm h-100 border-info">
      <div class="card-body">
        <h5 class="card-title text-info">Model Spotlight</h5>
        <p class="mb-2">
          This dashboard includes a regression model that predicts DGPT season points using player rating and number of events played.
        </p>
        <p class="mb-2">
          The model powers the Predictor and Projections pages, allowing users to test scenarios and compare expected outcomes.
        </p>
        <p class="mb-0">
          Together, the database, analytics views, and machine learning features create a complete sports analytics dashboard.
        </p>
      </div>
    </div>
  </div>
</div>

<script>
const homeChartLabels = <?= json_encode($chartLabels) ?>;
const homeChartValues = <?= json_encode($chartValues) ?>;

new Chart(document.getElementById('homePointsChart'), {
    type: 'bar',
    data: {
        labels: homeChartLabels,
        datasets: [{
            label: 'Points',
            data: homeChartValues,
            backgroundColor: [
                'rgba(54,162,235,0.75)',
                'rgba(75,192,192,0.75)',
                'rgba(255,159,64,0.75)',
                'rgba(153,102,255,0.75)',
                'rgba(255,99,132,0.75)'
            ],
            borderColor: 'rgba(0,0,0,0.15)',
            borderWidth: 1,
            borderRadius: 8,
            categoryPercentage: 0.65,
            barPercentage: 0.8
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false },
            title: { display: true, text: 'Top 5 Players by Points' }
        },
        scales: {
            x: {
                ticks: {
                    maxRotation: 30,
                    minRotation: 30
                },
                grid: {
                    display: false
                }
            },
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(0,0,0,0.08)'
                }
            }
        }
    }
});
</script>