<?php
$sql = "
  SELECT
    PDGA_Number,
    Player_Name,
    Rating,
    Points,
    Expected_Points,
    PAE,
    Include_in_PAE
  FROM pae_model
  ORDER BY PAE DESC
  LIMIT 50
";
$stmt = $pdo->query($sql);
$rows = $stmt->fetchAll();
?>

<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h2 class="mb-0">PAE Leaderboard</h2>
    <div class="text-muted">Points Above Expectation (model output)</div>
  </div>
  <span class="badge text-bg-dark">Top 50</span>
</div>

<div class="card shadow-sm">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-striped table-hover align-middle mb-0">
        <thead>
          <tr>
            <th>#</th>
            <th>PDGA</th>
            <th>Player</th>
            <th>Rating</th>
            <th>Points</th>
            <th>Expected</th>
            <th>PAE</th>
            <th>Points Above Expectation?</th>
          </tr>
        </thead>
        <tbody>
          <?php $rank = 1; ?>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td class="fw-semibold"><?php echo $rank++; ?></td>
              <td><?php echo htmlspecialchars($r["PDGA_Number"]); ?></td>
              <td class="fw-semibold"><?php echo htmlspecialchars($r["Player_Name"]); ?></td>
              <td><?php echo htmlspecialchars($r["Rating"]); ?></td>
              <td><?php echo htmlspecialchars($r["Points"]); ?></td>
              <td><?php echo htmlspecialchars($r["Expected_Points"]); ?></td>
              <td class="fw-bold"><?php echo htmlspecialchars($r["PAE"]); ?></td>
              <td>
                <?php if ($r["Include_in_PAE"] === "Include"): ?>
                  <span class="badge bg-success">Yes</span>
                <?php else: ?>
                  <span class="badge bg-secondary">No</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
