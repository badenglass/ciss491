<?php
require_once __DIR__ . '/../includes/security_log.php';

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    echo '<div class="alert alert-danger">Access denied. Admins only.</div>';
    return;
}

$success = "";
$error = "";

// Handle admin actions
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST["action"] ?? "";
    $userId = filter_input(INPUT_POST, "user_id", FILTER_VALIDATE_INT);

    if (!$userId || $userId <= 0) {
        $error = "Invalid user selected.";
        write_security_log("Admin user management action failed due to invalid user ID.");
    } else {
        // Prevent admin from locking/deleting themself accidentally if you want stricter control later
        if ($action === "lock") {
            $lockoutTime = (new DateTime())->modify("+15 years")->format("Y-m-d H:i:s");

            $stmt = $pdo->prepare("
                UPDATE users
                SET failed_attempts = 5, lockout_until = ?
                WHERE id = ?
            ");
            $stmt->execute([$lockoutTime, $userId]);

            $success = "Account locked successfully.";
            write_security_log("Admin locked user account ID {$userId}.");

        } elseif ($action === "unlock") {
            $stmt = $pdo->prepare("
                UPDATE users
                SET failed_attempts = 0, lockout_until = NULL
                WHERE id = ?
            ");
            $stmt->execute([$userId]);

            $success = "Account unlocked successfully.";
            write_security_log("Admin unlocked user account ID {$userId}.");

        } elseif ($action === "make_admin") {
            $stmt = $pdo->prepare("
                UPDATE users
                SET role = 'admin'
                WHERE id = ?
            ");
            $stmt->execute([$userId]);

            $success = "User promoted to admin.";
            write_security_log("Admin promoted user ID {$userId} to admin.");

        } elseif ($action === "make_user") {
            $stmt = $pdo->prepare("
                UPDATE users
                SET role = 'user'
                WHERE id = ?
            ");
            $stmt->execute([$userId]);

            $success = "Admin role removed from user.";
            write_security_log("Admin changed user ID {$userId} to standard user.");
        } else {
            $error = "Invalid action.";
            write_security_log("Admin submitted invalid action on user management page.");
        }
    }
}

$stmt = $pdo->query("
    SELECT
        id,
        username,
        role,
        failed_attempts,
        lockout_until,
        created_at
    FROM users
    ORDER BY created_at DESC
");

$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h2 class="mb-0">User Management</h2>
    <small class="text-muted">Admin-only account administration panel</small>
  </div>
</div>

<div class="alert alert-secondary">
  <strong>Overview:</strong>
  This page allows administrators to manage user accounts, roles, and account lockout status.
</div>

<?php if ($success !== ""): ?>
  <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<?php if ($error !== ""): ?>
  <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm">
  <div class="card-body">
    <h4 class="card-title mb-3">User Accounts</h4>

    <div class="table-responsive">
      <table class="table table-striped table-bordered align-middle">
        <thead>
          <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Role</th>
            <th>Failed Attempts</th>
            <th>Lockout Until</th>
            <th>Created At</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($users as $user): ?>
            <?php
              $isLocked = !empty($user["lockout_until"]) && strtotime($user["lockout_until"]) > time();
              $isSelf = isset($_SESSION["user_id"]) && (int)$_SESSION["user_id"] === (int)$user["id"];
            ?>
            <tr>
              <td><?= (int)$user["id"] ?></td>
              <td><?= htmlspecialchars($user["username"]) ?></td>
              <td>
                <span class="badge <?= $user["role"] === "admin" ? 'text-bg-warning' : 'text-bg-secondary' ?>">
                  <?= htmlspecialchars($user["role"]) ?>
                </span>
              </td>
              <td><?= (int)$user["failed_attempts"] ?></td>
              <td>
                <?php if ($isLocked): ?>
                  <span class="text-danger fw-bold"><?= htmlspecialchars($user["lockout_until"]) ?></span>
                <?php else: ?>
                  <span class="text-success">Not Locked</span>
                <?php endif; ?>
              </td>
              <td><?= htmlspecialchars($user["created_at"]) ?></td>
              <td>
                <div class="d-flex flex-wrap gap-2">
                  <?php if ($isLocked): ?>
                    <form method="post" class="d-inline">
                      <input type="hidden" name="user_id" value="<?= (int)$user["id"] ?>">
                      <input type="hidden" name="action" value="unlock">
                      <button type="submit" class="btn btn-sm btn-success">Unlock</button>
                    </form>
                  <?php else: ?>
                    <form method="post" class="d-inline">
                      <input type="hidden" name="user_id" value="<?= (int)$user["id"] ?>">
                      <input type="hidden" name="action" value="lock">
                      <button type="submit" class="btn btn-sm btn-danger" <?= $isSelf ? 'disabled' : '' ?>>Lock</button>
                    </form>
                  <?php endif; ?>

                  <?php if ($user["role"] === "user"): ?>
                    <form method="post" class="d-inline">
                      <input type="hidden" name="user_id" value="<?= (int)$user["id"] ?>">
                      <input type="hidden" name="action" value="make_admin">
                      <button type="submit" class="btn btn-sm btn-warning">Make Admin</button>
                    </form>
                  <?php else: ?>
                    <form method="post" class="d-inline">
                      <input type="hidden" name="user_id" value="<?= (int)$user["id"] ?>">
                      <input type="hidden" name="action" value="make_user">
                      <button type="submit" class="btn btn-sm btn-secondary" <?= $isSelf ? 'disabled' : '' ?>>Make User</button>
                    </form>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>