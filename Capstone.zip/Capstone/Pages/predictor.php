<?php
$stmt = $pdo->query("
    SELECT Player_Name, Rating, Events_Played, Points
    FROM raw_data
    WHERE Year = 2025
    ORDER BY Player_Name ASC
");

$players = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h2 class="mb-0">PDGA Points Predictor</h2>
    <small class="text-muted">Estimate season points using player rating and events played</small>
  </div>
</div>

<div class="alert alert-secondary">
  <strong>Predictor Overview:</strong>
  This tool uses our regression model to estimate a player's DGPT season points based on two inputs:
  player rating and number of events played. You can either select a player from the 2025 dataset or
  manually enter custom values.
</div>

<div class="row g-4">
  <div class="col-lg-7">
    <div class="card shadow-sm">
      <div class="card-body">
        <h4 class="card-title mb-4">Prediction Inputs</h4>

        <form id="predictionForm">
          <div class="mb-3">
            <label for="playerSelect" class="form-label">Select Player</label>
            <select id="playerSelect" class="form-select">
              <option value="">Custom Input</option>
              <?php foreach ($players as $row): ?>
                <option
                  value="<?= htmlspecialchars($row['Player_Name']) ?>"
                  data-rating="<?= $row['Rating'] ?>"
                  data-events="<?= $row['Events_Played'] ?>"
                  data-points="<?= $row['Points'] ?>"
                >
                  <?= htmlspecialchars($row['Player_Name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label for="rating" class="form-label">Player Rating</label>
            <input type="number" id="rating" class="form-control" step="0.01" required>
          </div>

          <div class="mb-3">
            <label for="events_played" class="form-label">Events Played</label>
            <input type="number" id="events_played" class="form-control" step="1" required>
          </div>

          <div class="d-grid">
            <button type="submit" class="btn btn-primary">Predict Points</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="card shadow-sm h-100 border-info">
      <div class="card-body">
        <h5 class="card-title text-info">How this tool works</h5>

        <p class="mb-2">
          The prediction model estimates a player's total DGPT season points using two main variables:
          <strong>player rating</strong> and <strong>number of events played</strong>.
        </p>

        <p class="mb-2">
          Rating represents competitive skill, while events played capture the number of opportunities
          a player has to earn points throughout the season.
        </p>

        <p class="mb-0">
          This makes the predictor useful for comparing players, testing scenarios, and estimating how
          season participation may affect total points.
        </p>
      </div>
    </div>
  </div>
</div>

<div id="output" class="mt-4"></div>

<script>
document.getElementById("playerSelect").addEventListener("change", function () {
    const option = this.options[this.selectedIndex];

    document.getElementById("rating").value = option.dataset.rating || "";
    document.getElementById("events_played").value = option.dataset.events || "";
});

document.getElementById("predictionForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const rating = parseFloat(document.getElementById("rating").value);
    const events = parseFloat(document.getElementById("events_played").value);

    const selected = document.getElementById("playerSelect").options[
        document.getElementById("playerSelect").selectedIndex
    ];

    const playerName = selected.value || "Custom Input";
    const actualPoints = selected.dataset.points ? parseFloat(selected.dataset.points) : null;

    fetch("Api/predict.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            rating: rating,
            events_played: events
        })
    })
    .then(res => res.json())
    .then(data => {
        const output = document.getElementById("output");

        if (!data.success) {
            output.innerHTML = `
                <div class="alert alert-danger">
                    ${data.message}
                </div>
            `;
            return;
        }

        const predictedPoints = parseFloat(data.predicted_points);
        const difference = actualPoints !== null ? (predictedPoints - actualPoints).toFixed(2) : null;

        output.innerHTML = `
            <div class="card shadow-sm">
              <div class="card-body">
                <h4 class="card-title mb-3">Prediction Result</h4>

                <div class="alert alert-primary">
                  <strong>Prediction Summary:</strong>
                  Based on the selected rating and number of events, the model estimates
                  <strong>${playerName}</strong> would earn approximately
                  <strong>${predictedPoints.toFixed(2)}</strong> DGPT points over the season.
                </div>

                <div class="row g-3 mb-4">
                  <div class="col-md-6 col-xl-3">
                    <div class="card border-primary h-100">
                      <div class="card-body">
                        <h6 class="text-muted mb-2">Player</h6>
                        <div class="fw-bold">${playerName}</div>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-6 col-xl-3">
                    <div class="card border-secondary h-100">
                      <div class="card-body">
                        <h6 class="text-muted mb-2">Rating</h6>
                        <div class="fw-bold">${data.rating}</div>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-6 col-xl-3">
                    <div class="card border-secondary h-100">
                      <div class="card-body">
                        <h6 class="text-muted mb-2">Events Played</h6>
                        <div class="fw-bold">${data.events_played}</div>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-6 col-xl-3">
                    <div class="card border-success h-100">
                      <div class="card-body">
                        <h6 class="text-muted mb-2">Predicted Points</h6>
                        <div class="fw-bold text-success">${predictedPoints.toFixed(2)}</div>
                      </div>
                    </div>
                  </div>
                </div>

                ${actualPoints !== null ? `
                  <div class="card mb-4 border-warning">
                    <div class="card-body">
                      <h5 class="card-title mb-3 text-warning">Actual vs Predicted</h5>
                      <p class="mb-2"><strong>Actual Points:</strong> ${actualPoints.toFixed(2)}</p>
                      <p class="mb-0">
                        <strong>Difference:</strong>
                        <span class="${difference >= 0 ? 'text-success fw-bold' : 'text-danger fw-bold'}">
                          ${difference}
                        </span>
                      </p>
                    </div>
                  </div>
                ` : ""}

                <div class="card border-info">
                  <div class="card-body">
                    <h5 class="card-title text-info">How to Interpret the Prediction</h5>

                    <p class="mb-2">
                      This result estimates a player's total DGPT points for a season based on two key
                      performance indicators: <strong>player rating</strong> and <strong>number of events played</strong>.
                    </p>

                    <p class="mb-2">
                      The regression model was built from historical MPO player data and identifies the
                      relationship between those variables and total season points.
                    </p>

                    <p class="mb-2">
                      Higher ratings generally correspond to stronger competitive performance, while playing
                      more events increases the number of opportunities to earn points.
                    </p>

                    <p class="mb-0">
                      The predicted value represents an expected point total for a player with the selected
                      inputs. Actual results may differ depending on tournament finishes, field strength,
                      injuries, and other factors not captured by the model.
                    </p>
                  </div>
                </div>
              </div>
            </div>
        `;
    })
    .catch(() => {
        document.getElementById("output").innerHTML = `
            <div class="alert alert-danger">
                Error connecting to the prediction API.
            </div>
        `;
    });
});
</script>