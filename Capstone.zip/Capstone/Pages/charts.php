<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h2 class="mb-0">Charts</h2>
    <small class="text-muted">Visual summary of top 2025 MPO player performance</small>
  </div>
</div>

<div class="alert alert-secondary">
<strong>Charts Overview:</strong>
These visualizations summarize top MPO players in the 2025 season using three metrics:
total points, player rating, and points above expectation (PAE). Together they provide
a quick view of performance, skill level, and efficiency relative to expectations.
</div>

<div class="row g-4">

<div class="col-lg-8">
<div class="card shadow-sm h-100">
<div class="card-body">
<h4 class="card-title mb-3">Top 10 by Points</h4>
<canvas id="chartPoints" height="140"></canvas>
</div>
</div>
</div>

<div class="col-lg-4">
<div class="card shadow-sm h-100 border-info">
<div class="card-body">
<h5 class="card-title text-info">What this chart shows</h5>

<p class="mb-2">
This chart displays the top 10 players by total season points.
</p>

<p class="mb-2">
Higher point totals generally reflect stronger finishes and more consistent
performance across tournaments.
</p>

<p class="mb-0">
This is a season-performance view rather than a pure skill-rating view.
</p>

</div>
</div>
</div>


<div class="col-lg-8">
<div class="card shadow-sm h-100">
<div class="card-body">
<h4 class="card-title mb-3">Top 10 by Rating</h4>
<canvas id="chartRating" height="140"></canvas>
</div>
</div>
</div>

<div class="col-lg-4">
<div class="card shadow-sm h-100 border-success">
<div class="card-body">
<h5 class="card-title text-success">What this chart shows</h5>

<p class="mb-2">
This chart shows the top 10 players by rating.
</p>

<p class="mb-2">
Player rating is a standardized measure of competitive skill based on
performance relative to course difficulty and event conditions.
</p>

<p class="mb-0">
Higher ratings usually indicate stronger overall playing ability.
</p>

</div>
</div>
</div>


<div class="col-lg-8">
<div class="card shadow-sm h-100">
<div class="card-body">
<h4 class="card-title mb-3">Top 10 by PAE</h4>
<canvas id="chartPAE" height="140"></canvas>
</div>
</div>
</div>

<div class="col-lg-4">
<div class="card shadow-sm h-100 border-warning">
<div class="card-body">
<h5 class="card-title text-warning">What this chart shows</h5>

<p class="mb-2">
This chart displays the top 10 players by Points Above Expectation (PAE).
</p>

<p class="mb-2">
PAE measures how much a player exceeded or fell short of expected performance
based on rating.
</p>

<p class="mb-0">
Higher PAE values suggest players are outperforming expectations more often.
</p>

</div>
</div>
</div>

</div>


<script>

async function buildBarChart(canvasId, url, labelField, valueField, titleText, suggestedMax = null) {

const res = await fetch(url);
const data = await res.json();

const labels = data.map(x => x[labelField]);
const values = data.map(x => Number(x[valueField]));

const ctx = document.getElementById(canvasId);

new Chart(ctx, {

type: 'bar',

data: {
labels: labels,

datasets: [{
label: titleText,
data: values,

backgroundColor: [
'rgba(54,162,235,0.75)',
'rgba(75,192,192,0.75)',
'rgba(255,159,64,0.75)',
'rgba(153,102,255,0.75)',
'rgba(255,99,132,0.75)',
'rgba(255,205,86,0.75)',
'rgba(201,203,207,0.75)',
'rgba(100,149,237,0.75)',
'rgba(60,179,113,0.75)',
'rgba(220,20,60,0.75)'
],

borderColor: 'rgba(0,0,0,0.15)',
borderWidth: 1,
borderRadius: 6,

categoryPercentage: 0.65,
barPercentage: 0.8

}]
},

options: {

responsive: true,

plugins: {
legend: { display: false },
title: { display: true, text: titleText }
},

scales: {

x: {
ticks: {
maxRotation: 45,
minRotation: 45
},
grid: {
display: false
}
},

y: {
beginAtZero: true,
...(suggestedMax ? { suggestedMax: suggestedMax } : {}),
grid: {
color: 'rgba(0,0,0,0.08)'
}
}

}

}

});

}

buildBarChart("chartPoints","Api/top10_points.php","Player_Name","Points","Top 10 by Points",3000);
buildBarChart("chartRating","Api/top10_rating.php","Player_Name","Rating","Top 10 by Rating");
buildBarChart("chartPAE","Api/top10_pae.php","Player_Name","PAE","Top 10 by PAE");

</script>