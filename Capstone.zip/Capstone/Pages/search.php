<?php
require_once __DIR__ . '/../includes/security_log.php';

$q = trim($_GET["q"] ?? "");
$q = mb_substr($q, 0, 50);

$rows = [];

if ($q !== "") {

  if (!ctype_digit($q) && mb_strlen($q) < 2) {

    write_security_log("Search query too short submitted.");

    echo '<div class="alert alert-warning">Please enter at least 2 characters for a name search.</div>';
    return;
  }

  if (ctype_digit($q)) {

    $stmt = $pdo->prepare("
      SELECT *
      FROM raw_data
      WHERE PDGA_Number = ?
      ORDER BY Player_Name ASC
      LIMIT 100
    ");

    $stmt->execute([$q]);

  } else {

    $stmt = $pdo->prepare("
      SELECT *
      FROM raw_data
      WHERE Player_Name LIKE ?
      ORDER BY Player_Name ASC
      LIMIT 100
    ");

    $stmt->execute(["%{$q}%"]);
  }

  $rows = $stmt->fetchAll();
}

$result_count = count($rows);
?>

<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h2 class="mb-0">Search Players</h2>
    <div class="text-muted">Search by PDGA number (exact) or player name (partial).</div>
  </div>

  <?php if ($q !== ""): ?>
    <span class="badge text-bg-dark">
      <?php echo number_format($result_count); ?> result<?php echo $result_count === 1 ? "" : "s"; ?>
    </span>
  <?php endif; ?>
</div>

<div class="card shadow-sm mb-3">
  <div class="card-body">
    <form class="row g-2" method="get" action="index.php">
      <input type="hidden" name="page" value="search">

      <div class="col-md-10">
        <input
          class="form-control form-control-lg"
          type="text"
          name="q"
          value="<?php echo htmlspecialchars($q); ?>"
          placeholder="Type a player name (ex: Buhr) or PDGA number (ex: 75412)"
          autocomplete="off"
        >
      </div>

      <div class="col-md-2 d-grid">
        <button class="btn btn-dark btn-lg" type="submit">Search</button>
      </div>
    </form>

    <?php if ($q === ""): ?>
      <div class="alert alert-secondary mb-0 mt-3">
        Enter a player name or PDGA number to begin.
      </div>
    <?php endif; ?>
  </div>
</div>

<?php if ($q !== ""): ?>
  <?php if ($result_count === 0): ?>
    <div class="alert alert-warning">
      No results found for <strong><?php echo htmlspecialchars($q); ?></strong>.
    </div>
  <?php else: ?>
    <div class="card shadow-sm">
      <div class="card-header bg-white d-flex align-items-center justify-content-between">
        <div class="fw-semibold">Results</div>
        <div class="text-muted small">
          Showing <?php echo number_format($result_count); ?> match<?php echo $result_count === 1 ? "" : "es"; ?>
        </div>
      </div>

      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-striped table-hover align-middle mb-0">
            <thead>
              <tr>
                <th>PDGA #</th>
                <th>Player</th>
                <th>Rating</th>
                <th>Points</th>
                <th>Events</th>
                <th>State</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rows as $r): ?>
                <tr>
                  <td>
                    <a class="text-decoration-none" href="index.php?page=search&q=<?php echo urlencode($r["PDGA_Number"]); ?>">
                      <?php echo htmlspecialchars($r["PDGA_Number"]); ?>
                    </a>
                  </td>
                  <td class="fw-semibold">
                    <a class="player-link" href="index.php?page=player&pdga=<?= urlencode($r['PDGA_Number']) ?>">
                      <?= htmlspecialchars($r['Player_Name']) ?>
                    </a>
                  </td>
                  <td><?php echo htmlspecialchars($r["Rating"]); ?></td>
                  <td><?php echo htmlspecialchars($r["Points"]); ?></td>
                  <td><?php echo htmlspecialchars($r["Events_Played"]); ?></td>
                  <td><?php echo htmlspecialchars($r["State"]); ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  <?php endif; ?>
<?php endif; ?>
