<?php
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    echo '<div class="alert alert-danger">Access denied. Admins only.</div>';
    return;
}

$logFile = __DIR__ . '/../logs/security.log';
$logEntries = [];

if (file_exists($logFile)) {
    $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $logEntries = array_reverse($lines);
}
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h2 class="mb-0">Security Dashboard</h2>
    <small class="text-muted">Admin-only application security logs</small>
  </div>
</div>

<div class="alert alert-secondary">
  <strong>Overview:</strong>
  This dashboard displays logged security-related activity from the PHP application.
</div>

<div class="card shadow-sm">
  <div class="card-body">
    <h4 class="card-title mb-3">Recent Security Events</h4>

    <?php if (empty($logEntries)): ?>
      <div class="alert alert-info mb-0">No security log entries found.</div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-striped table-bordered">
          <thead>
            <tr>
              <th>#</th>
              <th>Log Entry</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($logEntries as $i => $entry): ?>
              <tr>
                <td><?= $i + 1 ?></td>
                <td><code><?= htmlspecialchars($entry) ?></code></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>