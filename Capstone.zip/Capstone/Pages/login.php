<?php
require_once __DIR__ . '/../includes/security_log.php';

$login_error = "";
$register_error = "";
$register_success = "";

/*
---------------------------------------------------
LOGIN HANDLER
---------------------------------------------------
*/
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "login") {

    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    $username = mb_substr($username, 0, 50);

    if ($username === "" || $password === "") {

        $login_error = "Please enter both username and password.";
        write_security_log("Login attempt with missing username or password.");

    } else {

        $stmt = $pdo->prepare("
            SELECT id, username, password_hash, role, failed_attempts, lockout_until
            FROM users
            WHERE username = ?
            LIMIT 1
        ");
        $stmt->execute([$username]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {

            $now = new DateTime();
            $lockoutUntil = !empty($user["lockout_until"]) ? new DateTime($user["lockout_until"]) : null;

            if ($lockoutUntil && $lockoutUntil > $now) {

                $login_error = "This account is temporarily locked. Please try again later.";
                write_security_log("Locked account login attempt for username: " . $username);

            } elseif (password_verify($password, $user["password_hash"])) {

                $resetStmt = $pdo->prepare("
                    UPDATE users
                    SET failed_attempts = 0, lockout_until = NULL
                    WHERE id = ?
                ");
                $resetStmt->execute([$user["id"]]);

                $_SESSION["user_id"] = $user["id"];
                $_SESSION["username"] = $user["username"];
                $_SESSION["role"] = $user["role"];

                write_security_log("Successful login for username: " . $username);

                header("Location: index.php?page=home");
                exit;

            } else {

                $failedAttempts = (int)$user["failed_attempts"] + 1;
                $lockoutTime = null;

                if ($failedAttempts >= 5) {

                    $lockoutTime = (new DateTime())->modify("+15 minutes")->format("Y-m-d H:i:s");

                    $updateStmt = $pdo->prepare("
                        UPDATE users
                        SET failed_attempts = ?, lockout_until = ?
                        WHERE id = ?
                    ");
                    $updateStmt->execute([$failedAttempts, $lockoutTime, $user["id"]]);

                    $login_error = "Too many failed login attempts. Account locked for 15 minutes.";
                    write_security_log("Account locked after repeated failed logins for username: " . $username);

                } else {

                    $updateStmt = $pdo->prepare("
                        UPDATE users
                        SET failed_attempts = ?
                        WHERE id = ?
                    ");
                    $updateStmt->execute([$failedAttempts, $user["id"]]);

                    $remaining = 5 - $failedAttempts;

                    $login_error = "Invalid username or password. {$remaining} attempt(s) remaining before lockout.";
                    write_security_log("Failed login attempt for username: " . $username);
                }
            }

        } else {

            $login_error = "Invalid username or password.";
            write_security_log("Failed login attempt for unknown username: " . $username);
        }
    }
}

/*
---------------------------------------------------
REGISTRATION HANDLER
---------------------------------------------------
*/
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "register") {

    $new_username = trim($_POST["new_username"] ?? "");
    $new_password = $_POST["new_password"] ?? "";
    $confirm_password = $_POST["confirm_password"] ?? "";

    $new_username = mb_substr($new_username, 0, 50);

    if ($new_username === "" || $new_password === "" || $confirm_password === "") {

        $register_error = "Please complete all fields.";
        write_security_log("Registration attempt with missing fields.");

    } elseif ($new_password !== $confirm_password) {

        $register_error = "Passwords do not match.";
        write_security_log("Registration attempt with mismatched passwords.");

    } elseif (strlen($new_password) < 8) {

        $register_error = "Password must be at least 8 characters long.";
        write_security_log("Registration attempt with short password.");

    } else {

        $checkStmt = $pdo->prepare("
            SELECT id
            FROM users
            WHERE username = ?
            LIMIT 1
        ");
        $checkStmt->execute([$new_username]);

        $existingUser = $checkStmt->fetch(PDO::FETCH_ASSOC);

        if ($existingUser) {

            $register_error = "Username already exists.";
            write_security_log("Registration attempt with duplicate username.");

        } else {

            $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

            $insertStmt = $pdo->prepare("
                INSERT INTO users (username, password_hash, role)
                VALUES (?, ?, 'user')
            ");
            $insertStmt->execute([$new_username, $password_hash]);

            $register_success = "Account created successfully. You can now log in.";

            write_security_log("New user account created: " . $new_username);
        }
    }
}
?>

<div class="row justify-content-center g-4">

  <!-- LOGIN -->
  <div class="col-lg-5">
    <div class="card shadow-sm h-100">
      <div class="card-body">

        <h2 class="card-title mb-4">Login</h2>

        <?php if ($login_error !== ""): ?>
          <div class="alert alert-danger"><?= htmlspecialchars($login_error) ?></div>
        <?php endif; ?>

        <form method="post">
          <input type="hidden" name="action" value="login">

          <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>

          <div class="d-grid">
            <button type="submit" class="btn btn-dark">Login</button>
          </div>

        </form>

      </div>
    </div>
  </div>


  <!-- REGISTER -->
  <div class="col-lg-7">
    <div class="card shadow-sm h-100">
      <div class="card-body">

        <h2 class="card-title mb-4">Create Account</h2>

        <?php if ($register_error !== ""): ?>
          <div class="alert alert-danger"><?= htmlspecialchars($register_error) ?></div>
        <?php endif; ?>

        <?php if ($register_success !== ""): ?>
          <div class="alert alert-success"><?= htmlspecialchars($register_success) ?></div>
        <?php endif; ?>

        <form method="post">

          <input type="hidden" name="action" value="register">

          <div class="row g-3">

            <div class="col-md-6">
              <label class="form-label">Username</label>
              <input type="text" name="new_username" class="form-control" required>
            </div>

            <div class="col-md-6">
              <label class="form-label">Password</label>
              <input type="password" name="new_password" class="form-control" required>
            </div>

            <div class="col-md-6">
              <label class="form-label">Confirm Password</label>
              <input type="password" name="confirm_password" class="form-control" required>
            </div>

          </div>

          <div class="d-grid mt-4">
            <button type="submit" class="btn btn-primary">
              Create Account
            </button>
          </div>

        </form>

      </div>
    </div>
  </div>

</div>