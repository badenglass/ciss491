<h1>Dashboard</h1>
<p>Protected content goes here.</p>
