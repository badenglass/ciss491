<?php
$stmt = $pdo->query("
    SELECT 
        r.PDGA_Number,
        r.Player_Name,
        r.Rating,
        r.Events_Played,
        r.Points,
        p.PAE
    FROM raw_data r
    LEFT JOIN pae_model p
        ON r.PDGA_Number = p.PDGA_Number
    WHERE r.Year = 2025
    ORDER BY r.Points DESC
    LIMIT 200
");

$players = $stmt->fetchAll();

$player1Name = trim($_GET["player1"] ?? "");
$player2Name = trim($_GET["player2"] ?? "");

$player1Name = mb_substr($player1Name, 0, 100);
$player2Name = mb_substr($player2Name, 0, 100);

$player1 = null;
$player2 = null;

foreach ($players as $player) {
    if ($player["Player_Name"] === $player1Name) {
        $player1 = $player;
    }
    if ($player["Player_Name"] === $player2Name) {
        $player2 = $player;
    }
}

function getPredictedPoints($player) {
    if (!$player) {
        return null;
    }

    $payload = json_encode([
        "rating" => (float)$player["Rating"],
        "events_played" => (float)$player["Events_Played"]
    ]);

    if ($payload === false) {
        return null;
    }

    $ch = curl_init("http://localhost:8000/predict");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "X-API-Key: capstone-secure-key-2025"]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    if (curl_errno($ch)) {
        curl_close($ch);
        return null;
    }

    curl_close($ch);

    if ($httpCode === 200 && $response) {
        $apiResult = json_decode($response, true);

        if (is_array($apiResult) && isset($apiResult["predicted_points"])) {
            return $apiResult["predicted_points"];
        }
    }

    return null;
}

$player1Predicted = getPredictedPoints($player1);
$player2Predicted = getPredictedPoints($player2);
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h2 class="mb-0">Player Comparison Tool</h2>
    <small class="text-muted">Compare two 2025 MPO players side by side</small>
  </div>
</div>

<div class="alert alert-secondary">
  <strong>Comparison Overview:</strong>
  Select two players to compare rating, events played, actual points, PAE, and predicted points.
</div>

<div class="card shadow-sm mb-4">
  <div class="card-body">
    <form method="GET" class="row g-3 align-items-end">
      <input type="hidden" name="page" value="compare">

      <div class="col-md-5">
        <label for="player1" class="form-label">Player 1</label>
        <select name="player1" id="player1" class="form-select">
          <option value="">Select Player 1</option>
          <?php foreach ($players as $player): ?>
            <option value="<?= htmlspecialchars($player["Player_Name"]) ?>" <?= $player["Player_Name"] === $player1Name ? "selected" : "" ?>>
              <?= htmlspecialchars($player["Player_Name"]) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-5">
        <label for="player2" class="form-label">Player 2</label>
        <select name="player2" id="player2" class="form-select">
          <option value="">Select Player 2</option>
          <?php foreach ($players as $player): ?>
            <option value="<?= htmlspecialchars($player["Player_Name"]) ?>" <?= $player["Player_Name"] === $player2Name ? "selected" : "" ?>>
              <?= htmlspecialchars($player["Player_Name"]) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-2 d-grid">
        <button type="submit" class="btn btn-primary">Compare</button>
      </div>
    </form>
  </div>
</div>

<?php if ($player1 && $player2): ?>
<div class="row g-4">
  <div class="col-lg-6">
    <div class="card shadow-sm border-primary h-100">
      <div class="card-body">
        <h4 class="card-title text-primary"><?= htmlspecialchars($player1["Player_Name"]) ?></h4>
        <table class="table">
          <tr><th>Rating</th><td><?= number_format((float)$player1["Rating"], 0) ?></td></tr>
          <tr><th>Events Played</th><td><?= number_format((float)$player1["Events_Played"], 0) ?></td></tr>
          <tr><th>Actual Points</th><td><?= number_format((float)$player1["Points"], 2) ?></td></tr>
          <tr><th>PAE</th><td><?= $player1["PAE"] !== null ? number_format((float)$player1["PAE"], 2) : "Unavailable" ?></td></tr>
          <tr><th>Predicted Points</th><td><?= $player1Predicted !== null ? number_format((float)$player1Predicted, 2) : "Unavailable" ?></td></tr>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card shadow-sm border-success h-100">
      <div class="card-body">
        <h4 class="card-title text-success"><?= htmlspecialchars($player2["Player_Name"]) ?></h4>
        <table class="table">
          <tr><th>Rating</th><td><?= number_format((float)$player2["Rating"], 0) ?></td></tr>
          <tr><th>Events Played</th><td><?= number_format((float)$player2["Events_Played"], 0) ?></td></tr>
          <tr><th>Actual Points</th><td><?= number_format((float)$player2["Points"], 2) ?></td></tr>
          <tr><th>PAE</th><td><?= $player2["PAE"] !== null ? number_format((float)$player2["PAE"], 2) : "Unavailable" ?></td></tr>
          <tr><th>Predicted Points</th><td><?= $player2Predicted !== null ? number_format((float)$player2Predicted, 2) : "Unavailable" ?></td></tr>
        </table>
      </div>
    </div>
  </div>
</div>
<?php else: ?>
<div class="alert alert-info">
  Select two players and click <strong>Compare</strong> to view a side-by-side comparison.
</div>
<?php endif; ?>