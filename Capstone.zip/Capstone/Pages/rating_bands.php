<?php
$stmt = $pdo->query("
    SELECT
        Rating_Band,
        COUNT(*) AS Player_Count,
        AVG(Points) AS Avg_Points,
        AVG(Expected_Points) AS Avg_Expected,
        AVG(PAE) AS Avg_PAE
    FROM pae_model
    WHERE Include_In_PAE = 'Include'
    GROUP BY Rating_Band
    ORDER BY MIN(Rating)
");

$bands = $stmt->fetchAll(PDO::FETCH_ASSOC);

$labels = [];
$avgPoints = [];
$avgExpected = [];
$avgPAE = [];

foreach ($bands as $band) {
    $labels[] = $band["Rating_Band"];
    $avgPoints[] = round((float)$band["Avg_Points"], 2);
    $avgExpected[] = round((float)$band["Avg_Expected"], 2);
    $avgPAE[] = round((float)$band["Avg_PAE"], 2);
}
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h2 class="mb-0">Rating Band Analysis</h2>
    <small class="text-muted">Grouped performance by rating band</small>
  </div>
</div>

<div class="alert alert-secondary">
  <strong>Analysis Overview:</strong>
  This page compares actual points, expected points, and average PAE across rating bands.
  It shows how players perform relative to expectation within different skill ranges.
</div>

<div class="row g-3 mb-4">
  <div class="col-lg-8">
    <div class="card shadow-sm">
      <div class="card-body">
        <h4 class="card-title mb-3">Average Points vs Expected Points by Rating Band</h4>
        <canvas id="bandPointsChart" height="130"></canvas>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card shadow-sm border-info h-100">
      <div class="card-body">
        <h5 class="text-info">What this shows</h5>
        <p class="mb-2">This chart compares average actual points and average expected points in each rating band.</p>
        <p class="mb-0">It highlights whether players in certain skill ranges tend to outperform or underperform their expected totals.</p>
      </div>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-8">
    <div class="card shadow-sm">
      <div class="card-body">
        <h4 class="card-title mb-3">Average PAE by Rating Band</h4>
        <canvas id="bandPAEChart" height="130"></canvas>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card shadow-sm border-warning h-100">
      <div class="card-body">
        <h5 class="text-warning">What this shows</h5>
        <p class="mb-2">Positive average PAE means players in that band generally exceed expectation.</p>
        <p class="mb-0">Negative average PAE means players in that band generally fall short of expectation.</p>
      </div>
    </div>
  </div>
</div>

<div class="card shadow-sm mt-4">
  <div class="card-body">
    <h4 class="card-title mb-3">Rating Band Summary Table</h4>
    <div class="table-responsive">
      <table class="table table-striped">
        <thead>
          <tr>
            <th>Rating Band</th>
            <th>Players</th>
            <th>Avg Points</th>
            <th>Avg Expected</th>
            <th>Avg PAE</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($bands as $band): ?>
            <tr>
              <td><?= htmlspecialchars($band["Rating_Band"]) ?></td>
              <td><?= number_format((int)$band["Player_Count"]) ?></td>
              <td><?= number_format((float)$band["Avg_Points"], 2) ?></td>
              <td><?= number_format((float)$band["Avg_Expected"], 2) ?></td>
              <td class="<?= (float)$band["Avg_PAE"] >= 0 ? 'text-success fw-bold' : 'text-danger fw-bold' ?>">
                <?= number_format((float)$band["Avg_PAE"], 2) ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
const bandLabels = <?= json_encode($labels) ?>;
const avgPoints = <?= json_encode($avgPoints) ?>;
const avgExpected = <?= json_encode($avgExpected) ?>;
const avgPAE = <?= json_encode($avgPAE) ?>;

new Chart(document.getElementById('bandPointsChart'), {
  type: 'bar',
  data: {
    labels: bandLabels,
    datasets: [
      {
        label: 'Avg Points',
        data: avgPoints,
        backgroundColor: 'rgba(54,162,235,0.75)',
        borderRadius: 6
      },
      {
        label: 'Avg Expected',
        data: avgExpected,
        backgroundColor: 'rgba(255,159,64,0.75)',
        borderRadius: 6
      }
    ]
  },
  options: {
    responsive: true,
    scales: {
      x: {
        ticks: {
          maxRotation: 45,
          minRotation: 45
        }
      },
      y: { beginAtZero: true }
    }
  }
});

new Chart(document.getElementById('bandPAEChart'), {
  type: 'bar',
  data: {
    labels: bandLabels,
    datasets: [{
      label: 'Avg PAE',
      data: avgPAE,
      backgroundColor: avgPAE.map(v =>
        v >= 0 ? 'rgba(25,135,84,0.75)' : 'rgba(220,53,69,0.75)'
      ),
      borderRadius: 6
    }]
  },
  options: {
    responsive: true,
    scales: {
      x: {
        ticks: {
          maxRotation: 45,
          minRotation: 45
        }
      },
      y: { beginAtZero: true }
    }
  }
});
</script>