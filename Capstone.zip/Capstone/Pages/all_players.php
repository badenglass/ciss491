<?php
// pages/all_players.php

// Simple pagination (VERY important for large tables)
$perPage = 100;
$pageNum = max(1, (int)($_GET["p"] ?? 1));
$offset = ($pageNum - 1) * $perPage;

// Total count
$totalRows = (int)$pdo->query("SELECT COUNT(*) FROM raw_data")->fetchColumn();
$totalPages = (int)ceil($totalRows / $perPage);

// Fetch current page
$sql = "
  SELECT
    PDGA_Number,
    Player_Name,
    Rating,
    Points,
    Events_Played,
    State
  FROM raw_data
  ORDER BY Player_Name
  LIMIT :limit OFFSET :offset
";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(":limit", $perPage, PDO::PARAM_INT);
$stmt->bindValue(":offset", $offset, PDO::PARAM_INT);
$stmt->execute();
$rows = $stmt->fetchAll();
?>

<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h2 class="mb-0">All PDGA Players</h2>
    <div class="text-muted">
      Complete MPO 2025 dataset (<?php echo number_format($totalRows); ?> players)
    </div>
  </div>

  <span class="badge text-bg-dark">
    Page <?php echo $pageNum; ?> of <?php echo $totalPages; ?>
  </span>
</div>

<div class="card shadow-sm">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-striped table-hover align-middle mb-0">
        <thead>
          <tr>
            <th>PDGA #</th>
            <th>Player</th>
            <th>Rating</th>
            <th>Points</th>
            <th>Events</th>
            <th>State</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td><?php echo htmlspecialchars($r["PDGA_Number"]); ?></td>
              <td class="fw-semibold">
              <a class="player-link" href="index.php?page=player&pdga=<?= urlencode($r['PDGA_Number']) ?>">
                <?= htmlspecialchars($r['Player_Name']) ?>
              </a>
              </td>
              <td><?php echo htmlspecialchars($r["Rating"]); ?></td>
              <td><?php echo htmlspecialchars($r["Points"]); ?></td>
              <td><?php echo htmlspecialchars($r["Events_Played"]); ?></td>
              <td><?php echo htmlspecialchars($r["State"]); ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="d-flex justify-content-center mt-3">
  <form class="d-flex align-items-center gap-2" method="get" action="index.php">
    <input type="hidden" name="page" value="all_players">

    <label class="form-label mb-0 small text-muted" for="jumpPage">Jump to page</label>

    <input
      id="jumpPage"
      class="form-control"
      style="max-width: 120px;"
      type="number"
      name="p"
      min="1"
      max="<?php echo $totalPages; ?>"
      value="<?php echo $pageNum; ?>"
    >

    <button class="btn btn-dark" type="submit">Go</button>

    <span class="small text-muted">of <?php echo $totalPages; ?></span>
  </form>
</div>


<!-- Pagination -->
<nav class="mt-3">
  <ul class="pagination justify-content-center">

    <li class="page-item <?php echo $pageNum <= 1 ? "disabled" : ""; ?>">
      <a class="page-link" href="index.php?page=all_players&p=<?php echo $pageNum - 1; ?>">
        Previous
      </a>
    </li>

    <?php
    $start = max(1, $pageNum - 2);
    $end = min($totalPages, $pageNum + 2);
    for ($i = $start; $i <= $end; $i++):
    ?>
      <li class="page-item <?php echo $i === $pageNum ? "active" : ""; ?>">
        <a class="page-link" href="index.php?page=all_players&p=<?php echo $i; ?>">
          <?php echo $i; ?>
        </a>
      </li>
    <?php endfor; ?>

    <li class="page-item <?php echo $pageNum >= $totalPages ? "disabled" : ""; ?>">
      <a class="page-link" href="index.php?page=all_players&p=<?php echo $pageNum + 1; ?>">
        Next
      </a>
    </li>

  </ul>
</nav>
