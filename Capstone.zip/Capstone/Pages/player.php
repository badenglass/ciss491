<?php
require_once __DIR__ . '/../includes/security_log.php';

$pdga = filter_input(INPUT_GET, 'pdga', FILTER_VALIDATE_INT);

if ($pdga === false || $pdga === null || $pdga <= 0) {

    write_security_log("Invalid PDGA number submitted to player page.");

    echo '<div class="alert alert-danger">Invalid player ID.</div>';
    return;
}

$stmt = $pdo->prepare("
    SELECT
        r.PDGA_Number,
        r.Player_Name,
        r.Rating,
        r.Events_Played,
        CAST(REPLACE(r.Points, ',', '') AS UNSIGNED) AS PointsNum,
        p.PAE,
        p.Expected_Points
    FROM raw_data r
    LEFT JOIN pae_model p
      ON r.PDGA_Number = p.PDGA_Number
    WHERE r.Year = 2025
      AND r.PDGA_Number = ?
    LIMIT 1
");
$stmt->execute([$pdga]);
$player = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$player) {

    write_security_log("Player lookup failed for valid PDGA number.");

    echo '<div class="alert alert-danger">Player not found.</div>';
    return;
}

$payload = json_encode([
    "rating" => (float)$player["Rating"],
    "events_played" => (float)$player["Events_Played"]
]);

$ch = curl_init("http://localhost:8000/predict");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "X-API-Key: capstone-secure-key-2025"
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$predictedPoints = null;
if ($httpCode === 200 && $response) {
    $apiResult = json_decode($response, true);
    $predictedPoints = $apiResult["predicted_points"] ?? null;
}

$status = "Meeting Expectation";
$statusClass = "secondary";

if (isset($player["PAE"])) {
    if ((float)$player["PAE"] > 0) {
        $status = "Overperforming";
        $statusClass = "success";
    } elseif ((float)$player["PAE"] < 0) {
        $status = "Underperforming";
        $statusClass = "danger";
    }
}

$compareLabels = ["Actual", "Expected", "Predicted"];
$compareValues = [
    (float)$player["PointsNum"],
    (float)($player["Expected_Points"] ?? 0),
    (float)($predictedPoints ?? 0)
];
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h2 class="mb-0"><?= htmlspecialchars($player["Player_Name"]) ?></h2>
    <small class="text-muted">PDGA #<?= htmlspecialchars($player["PDGA_Number"]) ?></small>
  </div>
  <a class="btn btn-outline-dark" href="index.php?page=search">Back to Search</a>
</div>

<div class="row g-3 mb-4">
  <div class="col-md-4">
    <div class="card shadow-sm border-<?= $statusClass ?> h-100">
      <div class="card-body">
        <div class="text-muted small">Performance Status</div>
        <div class="fs-4 fw-bold text-<?= $statusClass ?>"><?= $status ?></div>
        <div class="small text-muted">Based on current PAE</div>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card shadow-sm h-100">
      <div class="card-body">
        <div class="text-muted small">Rating</div>
        <div class="fs-3 fw-bold"><?= number_format((float)$player["Rating"], 0) ?></div>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card shadow-sm h-100">
      <div class="card-body">
        <div class="text-muted small">Events Played</div>
        <div class="fs-3 fw-bold"><?= number_format((float)$player["Events_Played"], 0) ?></div>
      </div>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="card shadow-sm h-100">
      <div class="card-body">
        <h4 class="card-title mb-3">Player Scorecard</h4>
        <table class="table">
          <tr><th>Actual Points</th><td><?= number_format((float)$player["PointsNum"], 2) ?></td></tr>
          <tr><th>Expected Points</th><td><?= isset($player["Expected_Points"]) ? number_format((float)$player["Expected_Points"], 2) : "Unavailable" ?></td></tr>
          <tr><th>PAE</th><td><?= isset($player["PAE"]) ? number_format((float)$player["PAE"], 2) : "Unavailable" ?></td></tr>
          <tr><th>Predicted Points</th><td><?= $predictedPoints !== null ? number_format((float)$predictedPoints, 2) : "Unavailable" ?></td></tr>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-7">
    <div class="card shadow-sm h-100">
      <div class="card-body">
        <h4 class="card-title mb-3">Actual vs Expected vs Predicted</h4>
        <canvas id="profileChart" height="140"></canvas>
      </div>
    </div>
  </div>
</div>

<script>
const profileLabels = <?= json_encode($compareLabels) ?>;
const profileValues = <?= json_encode($compareValues) ?>;

new Chart(document.getElementById('profileChart'), {
  type: 'bar',
  data: {
    labels: profileLabels,
    datasets: [{
      label: 'Points',
      data: profileValues,
      backgroundColor: [
        'rgba(54,162,235,0.75)',
        'rgba(255,159,64,0.75)',
        'rgba(25,135,84,0.75)'
      ],
      borderRadius: 6
    }]
  },
  options: {
    responsive: true,
    plugins: {
      legend: { display: false }
    },
    scales: {
      y: { beginAtZero: true }
    }
  }
});
</script>