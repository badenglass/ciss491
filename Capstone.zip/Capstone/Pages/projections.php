<?php
$stmt = $pdo->query("
    SELECT Player_Name, Rating, Events_Played, Points
    FROM raw_data
    WHERE Year = 2025
    ORDER BY Points DESC
    LIMIT 100
");

$players = $stmt->fetchAll();

$apiPlayers = [];

foreach ($players as $player) {
    $apiPlayers[] = [
        "rating" => (float)$player["Rating"],
        "events_played" => (float)$player["Events_Played"]
    ];
}

$payload = json_encode([
    "players" => $apiPlayers
]);

$ch = curl_init("http://localhost:8000/predict_batch");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "X-API-Key: capstone-secure-key-2025"
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$predictions = [];

if ($httpCode === 200 && $response) {
    $apiResult = json_decode($response, true);
    if (isset($apiResult["results"])) {
        $predictions = $apiResult["results"];
    }
}

$rows = [];

foreach ($players as $index => $player) {
    $predictedPoints = $predictions[$index]["predicted_points"] ?? null;
    $actualPoints = (float)$player["Points"];
    $difference = $predictedPoints !== null ? $predictedPoints - $actualPoints : null;

    $rows[] = [
        "Player_Name" => $player["Player_Name"],
        "Rating" => (float)$player["Rating"],
        "Events_Played" => (float)$player["Events_Played"],
        "Actual_Points" => $actualPoints,
        "Predicted_Points" => $predictedPoints,
        "Difference" => $difference
    ];
}

usort($rows, function ($a, $b) {
    return ($b["Predicted_Points"] ?? 0) <=> ($a["Predicted_Points"] ?? 0);
});

$topChartRows = array_slice($rows, 0, 10);

$chartLabels = [];
$chartActual = [];
$chartPredicted = [];
$errorLabels = [];
$errorValues = [];

foreach ($topChartRows as $row) {
    $chartLabels[] = $row["Player_Name"];
    $chartActual[] = round($row["Actual_Points"], 2);
    $chartPredicted[] = $row["Predicted_Points"] !== null ? round($row["Predicted_Points"], 2) : 0;
    $errorLabels[] = $row["Player_Name"];
    $errorValues[] = $row["Difference"] !== null ? round($row["Difference"], 2) : 0;
}

$validRows = array_filter($rows, function ($row) {
    return $row["Predicted_Points"] !== null && $row["Difference"] !== null;
});

$highestPredictedPlayer = null;
$avgError = 0;
$mostOverpredicted = null;
$mostUnderpredicted = null;

if (!empty($validRows)) {
    $sumError = 0;
    $highestPredictedPlayer = $rows[0];

    $mostOverpredicted = $validRows[array_key_first($validRows)];
    $mostUnderpredicted = $validRows[array_key_first($validRows)];

    foreach ($validRows as $row) {
        $sumError += $row["Difference"];

        if ($row["Difference"] > $mostOverpredicted["Difference"]) {
            $mostOverpredicted = $row;
        }

        if ($row["Difference"] < $mostUnderpredicted["Difference"]) {
            $mostUnderpredicted = $row;
        }
    }

    $avgError = $sumError / count($validRows);
}
?>

<div class="row g-3 mb-4">
  <div class="col-md-6 col-xl-3">
    <div class="card shadow-sm border-primary h-100">
      <div class="card-body">
        <h6 class="text-muted mb-2">Highest Predicted Player</h6>
        <h5 class="mb-1">
          <?= $highestPredictedPlayer ? htmlspecialchars($highestPredictedPlayer["Player_Name"]) : "N/A" ?>
        </h5>
        <div class="text-primary fw-bold">
          <?= $highestPredictedPlayer ? number_format($highestPredictedPlayer["Predicted_Points"], 2) . " points" : "N/A" ?>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-6 col-xl-3">
    <div class="card shadow-sm border-secondary h-100">
      <div class="card-body">
        <h6 class="text-muted mb-2">Average Prediction Error</h6>
        <h5 class="<?= $avgError >= 0 ? 'text-success' : 'text-danger' ?>">
          <?= number_format($avgError, 2) ?>
        </h5>
        <div class="small text-muted">
          Predicted minus actual
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-6 col-xl-3">
    <div class="card shadow-sm border-success h-100">
      <div class="card-body">
        <h6 class="text-muted mb-2">Most Overpredicted</h6>
        <h5 class="mb-1">
          <?= $mostOverpredicted ? htmlspecialchars($mostOverpredicted["Player_Name"]) : "N/A" ?>
        </h5>
        <div class="text-success fw-bold">
          <?= $mostOverpredicted ? number_format($mostOverpredicted["Difference"], 2) : "N/A" ?>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-6 col-xl-3">
    <div class="card shadow-sm border-danger h-100">
      <div class="card-body">
        <h6 class="text-muted mb-2">Most Underpredicted</h6>
        <h5 class="mb-1">
          <?= $mostUnderpredicted ? htmlspecialchars($mostUnderpredicted["Player_Name"]) : "N/A" ?>
        </h5>
        <div class="text-danger fw-bold">
          <?= $mostUnderpredicted ? number_format($mostUnderpredicted["Difference"], 2) : "N/A" ?>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="alert alert-secondary">
  <strong>Table description:</strong>
  This table ranks the top 100 players by model-predicted DGPT points for 2025. It compares each player's
  actual recorded points to the predicted points generated by the regression model using rating and events played.
  The Difference column shows how far above or below the actual result the prediction was.
</div>

<div class="card shadow-sm">
  <div class="card-body">
    <h2 class="card-title mb-4">Top 100 2025 Season Projection Leaderboard</h2>

    <div class="table-responsive">
      <table class="table table-striped table-bordered align-middle">
        <thead class="table-dark">
          <tr>
            <th>Rank</th>
            <th>Player</th>
            <th>Rating</th>
            <th>Events Played</th>
            <th>Actual Points</th>
            <th>Predicted Points</th>
            <th>Difference</th>
          </tr>
        </thead>
        <tbody>
          <?php $rank = 1; ?>
          <?php foreach ($rows as $row): ?>
            <tr>
              <td><?= $rank++ ?></td>
              <td><?= htmlspecialchars($row["Player_Name"]) ?></td>
              <td><?= number_format($row["Rating"], 0) ?></td>
              <td><?= number_format($row["Events_Played"], 0) ?></td>
              <td><?= number_format($row["Actual_Points"], 2) ?></td>
              <td><?= $row["Predicted_Points"] !== null ? number_format($row["Predicted_Points"], 2) : "Error" ?></td>
              <td class="<?= ($row["Difference"] ?? 0) >= 0 ? 'text-success fw-bold' : 'text-danger fw-bold' ?>">
                <?= $row["Difference"] !== null ? number_format($row["Difference"], 2) : "Error" ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="row mt-4">
  <div class="col-lg-8">
    <div class="card shadow-sm h-100">
      <div class="card-body">
        <h3 class="card-title mb-3">Top 10 Players: Actual vs Model-Predicted DGPT Points</h3>
        <canvas id="projectionChart" height="120"></canvas>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card shadow-sm h-100 border-info">
      <div class="card-body">
        <h5 class="card-title text-info">What this chart shows</h5>
        <p class="mb-2">
          This chart compares each player's actual 2025 DGPT points to the points predicted by the regression model.
        </p>
        <p class="mb-2">
          The blue bars represent the real points currently stored in the database, while the red bars represent the
          model's predicted point totals based on player rating and number of events played.
        </p>
        <p class="mb-0">
          This makes it easier to see how closely the model matches real performance for the top projected players.
        </p>
      </div>
    </div>
  </div>
</div>

<div class="row mt-4">
  <div class="col-lg-8">
    <div class="card shadow-sm h-100">
      <div class="card-body">
        <h3 class="card-title mb-3">Top 10 Players: Prediction Error</h3>
        <canvas id="errorChart" height="120"></canvas>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card shadow-sm h-100 border-warning">
      <div class="card-body">
        <h5 class="card-title text-warning">What this chart shows</h5>
        <p class="mb-2">
          This chart displays the prediction error for each player, calculated as predicted points minus actual points.
        </p>
        <p class="mb-2">
          Green bars indicate the model overpredicted the player's total.
        </p>
        <p class="mb-0">
          Red bars indicate the model underpredicted the player's total.
        </p>
      </div>
    </div>
  </div>
</div>

<div class="row mt-4">
  <div class="col-lg-12">
    <div class="card shadow-sm border-primary">
      <div class="card-body">
        <h3 class="card-title text-primary">Model Evaluation</h3>
        <p class="mb-3">
          The regression model predicts DGPT points using player rating and number of events played.
          Predictions are generated dynamically through a Python machine learning API connected to this dashboard.
        </p>
        <p class="mb-3">
          The leaderboard and charts above allow users to evaluate how closely the model predictions align with
          actual player performance during the 2025 season.
        </p>
        <p class="mb-0">
          Prediction differences highlight where the model overestimates or underestimates performance,
          helping identify strengths and limitations of the regression approach.
        </p>
      </div>
    </div>
  </div>
</div>

<script>
const projectionLabels = <?= json_encode($chartLabels) ?>;
const actualPointsData = <?= json_encode($chartActual) ?>;
const predictedPointsData = <?= json_encode($chartPredicted) ?>;
const errorLabels = <?= json_encode($errorLabels) ?>;
const errorValues = <?= json_encode($errorValues) ?>;

new Chart(document.getElementById('projectionChart'), {
    type: 'bar',
    data: {
        labels: projectionLabels,
        datasets: [
            {
                label: 'Actual Points',
                data: actualPointsData,
                backgroundColor: 'rgba(54,162,235,0.7)'
            },
            {
                label: 'Predicted Points',
                data: predictedPointsData,
                backgroundColor: 'rgba(255,99,132,0.7)'
            }
        ]
    },
    options: { responsive: true }
});

new Chart(document.getElementById('errorChart'), {
    type: 'bar',
    data: {
        labels: errorLabels,
        datasets: [
            {
                label: 'Prediction Error',
                data: errorValues,
                backgroundColor: errorValues.map(v =>
                    v >= 0 ? 'rgba(25,135,84,0.7)' : 'rgba(220,53,69,0.7)'
                )
            }
        ]
    },
    options: { responsive: true }
});
</script>