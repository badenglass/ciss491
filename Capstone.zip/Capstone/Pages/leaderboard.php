<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h2 class="mb-0">Interactive Leaderboard</h2>
    <small class="text-muted">Explore top players by rating, points, or PAE</small>
  </div>
</div>

<div class="alert alert-secondary">
  <strong>Leaderboard Overview:</strong>
  This page lets users dynamically explore top-performing players by different metrics.
  Use the controls below to switch between rating, points, and points above expectation (PAE),
  and adjust how many players are displayed.
</div>

<div class="card shadow-sm mb-4">
  <div class="card-body">
    <div class="row g-3 align-items-end">
      <div class="col-md-4">
        <label for="metricSelect" class="form-label">Metric</label>
        <select id="metricSelect" class="form-select">
          <option value="Points" selected>Points</option>
          <option value="Rating">Rating</option>
          <option value="PAE">PAE</option>
        </select>
      </div>

      <div class="col-md-4">
        <label for="limitSelect" class="form-label">Show Top</label>
        <select id="limitSelect" class="form-select">
          <option value="5">Top 5</option>
          <option value="10" selected>Top 10</option>
          <option value="25">Top 25</option>
          <option value="50">Top 50</option>
        </select>
      </div>

      <div class="col-md-4 d-grid">
        <button id="loadLeaderboardBtn" class="btn btn-dark">Update Leaderboard</button>
      </div>
    </div>
  </div>
</div>

<div class="row g-4">
  <div class="col-lg-8">
    <div class="card shadow-sm h-100">
      <div class="card-body">
        <h4 class="card-title mb-3">Leaderboard Chart</h4>
        <canvas id="leaderboardChart" height="120"></canvas>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card shadow-sm h-100 border-info">
      <div class="card-body">
        <h5 class="card-title text-info">What this chart shows</h5>
        <p class="mb-2">
          This chart visualizes the current leaderboard based on the selected metric and size.
        </p>
        <p class="mb-2">
          Rating highlights player skill, Points reflect season totals, and PAE shows how much a player exceeded expectation.
        </p>
        <p class="mb-0">
          The chart scale automatically adjusts by metric so the differences between players are easier to see.
        </p>
      </div>
    </div>
  </div>
</div>

<div class="card shadow-sm mt-4">
  <div class="card-body">
    <h4 class="card-title mb-3">Leaderboard Table</h4>
    <div class="table-responsive">
      <table class="table table-striped table-hover align-middle mb-0" id="leaderboardTable">
        <thead>
          <tr>
            <th>Rank</th>
            <th>Player</th>
            <th id="ratingHeader">Rating</th>
            <th>Events Played</th>
            <th id="metricHeader">Metric</th>
          </tr>
        </thead>
        <tbody id="leaderboardTableBody">
          <tr>
            <td colspan="5" class="text-center text-muted">Loading...</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
let leaderboardChart = null;

async function loadLeaderboard() {
    const metric = document.getElementById('metricSelect').value;
    const limit = document.getElementById('limitSelect').value;

    const response = await fetch(`Api/leaderboard_data.php?metric=${encodeURIComponent(metric)}&limit=${encodeURIComponent(limit)}`);
    const data = await response.json();

    if (!data.success) {
        document.getElementById('leaderboardTableBody').innerHTML = `
            <tr>
                <td colspan="5" class="text-center text-danger">${escapeHtml(data.message)}</td>
            </tr>
        `;
        return;
    }

    const rows = data.rows;
    const labels = rows.map(row => row.Player_Name);
    const values = rows.map(row => Number(row.MetricValue));

    document.getElementById('metricHeader').textContent = metric;

    const ratingHeader = document.getElementById('ratingHeader');
    if (metric === "Rating") {
        ratingHeader.style.display = "none";
    } else {
        ratingHeader.style.display = "";
    }

    const tbody = document.getElementById('leaderboardTableBody');
    tbody.innerHTML = '';

    rows.forEach((row, index) => {
        const tr = document.createElement('tr');

        let rowHtml = `
            <td>${index + 1}</td>
            <td>
              <a class="player-link" href="index.php?page=player&pdga=${encodeURIComponent(row.PDGA_Number)}">
                ${escapeHtml(row.Player_Name)}
              </a>
            </td>
        `;

        if (metric !== "Rating") {
            rowHtml += `<td>${formatValue(row.Rating)}</td>`;
        }

        rowHtml += `
            <td>${formatValue(row.Events_Played)}</td>
            <td>${formatValue(row.MetricValue)}</td>
        `;

        tr.innerHTML = rowHtml;
        tbody.appendChild(tr);
    });

    const ctx = document.getElementById('leaderboardChart');

    if (leaderboardChart) {
        leaderboardChart.destroy();
    }

    let yOptions = {
        beginAtZero: true,
        grid: {
            color: 'rgba(0,0,0,0.08)'
        }
    };

    if (values.length > 0) {
        const minValue = Math.min(...values);
        const maxValue = Math.max(...values);

        let range = maxValue - minValue;

        if (metric === "Rating") {
            range = Math.max(range, 10);
        } else if (metric === "Points") {
            range = Math.max(range, 2000);
        } else if (metric === "PAE") {
            range = Math.max(range, 100);
        }

        let padding = range * 0.03;

        if (metric === "Points") {
            yOptions = {
                min: Math.max(0, minValue - padding),
                max: maxValue + padding,
                grid: {
                    color: 'rgba(0,0,0,0.08)'
                }
            };
        } else {
            yOptions = {
                min: minValue - padding,
                max: maxValue + padding,
                grid: {
                    color: 'rgba(0,0,0,0.08)'
                }
            };
        }
    }

    leaderboardChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: `${metric} Leaderboard`,
                data: values,
                backgroundColor: [
                    'rgba(54,162,235,0.75)',
                    'rgba(75,192,192,0.75)',
                    'rgba(255,159,64,0.75)',
                    'rgba(153,102,255,0.75)',
                    'rgba(255,99,132,0.75)',
                    'rgba(255,205,86,0.75)',
                    'rgba(201,203,207,0.75)',
                    'rgba(100,149,237,0.75)',
                    'rgba(60,179,113,0.75)',
                    'rgba(220,20,60,0.75)'
                ],
                borderColor: 'rgba(0,0,0,0.15)',
                borderWidth: 1,
                borderRadius: 6,
                categoryPercentage: 0.65,
                barPercentage: 0.8
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false },
                title: { display: true, text: `Top ${limit} by ${metric}` }
            },
            scales: {
                x: {
                    ticks: {
                        maxRotation: 35,
                        minRotation: 35
                    },
                    grid: {
                        display: false
                    }
                },
                y: yOptions
            }
        }
    });
}

function formatValue(value) {
    if (value === null || value === undefined || value === '') {
        return 'N/A';
    }

    const num = Number(value);

    if (Number.isNaN(num)) {
        return value;
    }

    return num % 1 === 0 ? num.toLocaleString() : num.toFixed(2);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

document.getElementById('loadLeaderboardBtn').addEventListener('click', loadLeaderboard);
window.addEventListener('DOMContentLoaded', loadLeaderboard);
</script>